package br.feevale.ameacaambientaissqlite;

import androidx.annotation.NonNull;

import java.io.Serializable;

public class Ameaca implements Serializable {


    private String ameacas;
    private String endereco;
    private String data;
    private String descricao;
    private String imagem;

    public Ameaca(){

    }



    public String getEndereco(){
        return endereco;
    }

    public void setEndereco(String endereco){
        this.endereco = endereco;
    }

    public String getData(){
        return data;
    }

    public void setData(String data){
        this.data = data;
    }

    public String getDescricao(){
        return descricao;
    }

    public void setDescricao(String descricao){
        this.descricao = descricao;
    }

    public String getImagem() { return imagem;}

    public void setImagem(String imagem) { this.imagem = imagem; }

    public String getAmeacas() {
        return ameacas;
    }

    public void setAmeacas(String ameacas) {
        this.ameacas = ameacas;
    }

    @NonNull
    @Override
    public String toString(){
        return ameacas + " " + descricao + " " + endereco + " " + data + " " + imagem;
    }
}
