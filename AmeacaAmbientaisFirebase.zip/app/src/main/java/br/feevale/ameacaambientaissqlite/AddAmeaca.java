package br.feevale.ameacaambientaissqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import android.content.Intent;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.util.Base64;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;


public class AddAmeaca extends AppCompatActivity {
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference root = database.getReference();
    DatabaseReference ameacas = root.child(MainActivity.AMEACA_KEY);
    EditText txtEndereco, txtData, txtDescricao;
    public static final int CAMERA_CALL = 1022;
    Bitmap bmp;
    ImageView image;
    Boolean hasImage = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_ameaca);

        txtEndereco = findViewById(R.id.txtEndereco);
        txtData = findViewById(R.id.txtData);
        txtDescricao = findViewById(R.id.txtDescricao);
        image = findViewById(R.id.image);

    }

    public String loadImage(){
        ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 100, byteOut);
        return Base64.encodeToString(byteOut.toByteArray(), Base64.DEFAULT);
    }

    public void addAmeaca(View v){
        Ameaca a = new Ameaca();
        a.setEndereco(txtEndereco.getText().toString());
        a.setData(txtData.getText().toString());
        a.setDescricao(txtDescricao.getText().toString());

        if(hasImage){
            String bmpEncoded = loadImage();
            hasImage = false;
            a.setImagem(bmpEncoded);
        }

        String key = ameacas.push().getKey();
        ameacas.child(key).setValue(a);
        finish();
    }

    public void takePicture(View v){
        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(camera, CAMERA_CALL);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == CAMERA_CALL && resultCode == RESULT_OK) {
            bmp = (Bitmap) data.getExtras().get("data");
            image.setImageBitmap(bmp);
            hasImage = true;
        }
    }

}