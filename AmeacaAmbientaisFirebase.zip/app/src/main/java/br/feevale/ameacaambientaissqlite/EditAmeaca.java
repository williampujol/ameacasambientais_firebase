package br.feevale.ameacaambientaissqlite;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class EditAmeaca extends AppCompatActivity {

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference root = database.getReference();
    DatabaseReference ameacas = root.child(MainActivity.AMEACA_KEY);
    EditText txtEndereco, txtData, txtDescricao;
    Ameaca current;
    String key;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_ameaca);

        txtEndereco = findViewById(R.id.txtEndereco);
        txtData = findViewById(R.id.txtData);
        txtDescricao = findViewById(R.id.txtDescricao);

        key = getIntent().getStringExtra("KEY");
        current = (Ameaca) getIntent().getSerializableExtra("AMC");

        txtEndereco.setText(current.getEndereco());
        txtData.setText(current.getData());
        txtDescricao.setText(current.getDescricao());
    }

    public void updateAmeaca(View v){
        current.setEndereco(txtEndereco.getText().toString());
        current.setData(txtData.getText().toString());
        current.setDescricao(txtDescricao.getText().toString());

        ameacas.child(key).setValue(current);
        finish();
    }
}